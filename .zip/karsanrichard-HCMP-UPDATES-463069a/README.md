# HCMP-UPDATES
This will only contain altered files for the above system

Only updated files shall be stored in this repository for the sake of faster remote updates. 
This is NOT the project in its entirety.

God Speed
